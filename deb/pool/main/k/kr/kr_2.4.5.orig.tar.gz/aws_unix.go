// +build !darwin

package kr

const NTP_UPDATE_CMD = "sudo ntpdate pool.ntp.org"
