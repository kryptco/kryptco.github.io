Thanks for your interest in contributing to Kryptonite!

We are currently researching what type of license makes the most sense for Kryptonite. In the meantime, we ask that each commit of a contribution contain the following text:

```
I agree to license all rights to my contributions in each modified file exclusively to KryptCo, Inc.
```

This allows us to include your contribution in our product and to relicense it under the same license Kryptonite uses.

Feel free to reach out with any questions to code@krypt.co
