import PackageDescription

let package = Package(
    name: "krbtle"
)
