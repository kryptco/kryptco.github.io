package kr

const NTP_UPDATE_CMD = "sudo ntpdate -u time.apple.com"
