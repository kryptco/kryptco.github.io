package kr

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/blang/semver"
	"golang.org/x/crypto/openpgp/armor"
)

//	Previous enclave versions assume SHA1 for all RSA keys regardless of the PubKeyAlgorithm specified in the signature payload
var ENCLAVE_VERSION_SUPPORTS_RSA_SHA2_256_512 = semver.MustParse("2.1.0")
var ENCLAVE_VERSION_SUPPORTS_KRYPTON_ASCII_ARMOR_HEADERS = semver.MustParse("2.3.1")

type Request struct {
	RequestID      string          `json:"request_id"`
	UnixSeconds    int64           `json:"unix_seconds"`
	Version        semver.Version  `json:"v"`
	SendACK        bool            `json:"a"`
	SignRequest    *SignRequest    `json:"sign_request,omitempty"`
	GitSignRequest *GitSignRequest `json:"git_sign_request,omitempty"`
	MeRequest      *MeRequest      `json:"me_request,omitempty"`
	UnpairRequest  *UnpairRequest  `json:"unpair_request,omitempty"`
	HostsRequest   *HostsRequest   `json:"hosts_request,omitempty"`

	ReadTeamRequest      *ReadTeamRequest      `json:"read_team_request,omitempty"`
	TeamOperationRequest *TeamOperationRequest `json:"team_operation_request,omitempty"`
	LogDecryptionRequest *json.RawMessage      `json:"log_decryption_request,omitempty"`
}

func NewRequest() (request Request, err error) {
	err = request.Prepare()
	return
}

func (r *Request) Prepare() (err error) {
	if r.RequestID == "" {
		id, idErr := Rand128Base62()
		if idErr != nil {
			err = idErr
			return
		}
		r.RequestID = id
	}
	r.UnixSeconds = time.Now().Unix()
	r.Version = CURRENT_VERSION
	r.SendACK = true
	return
}

func (r Request) NotifyPrefix() string {
	return fmt.Sprintf("[%s]", r.RequestID)
}

type RequestParameters struct {
	AlertText string
	Timeout   TimeoutPhases
}

func (r Request) RequestParameters(timeouts Timeouts) RequestParameters {
	if r.SignRequest != nil {
		return RequestParameters{
			AlertText: "Incoming SSH request. Open Krypton to continue.",
			Timeout:   timeouts.Sign,
		}
	}
	if r.GitSignRequest != nil {
		return RequestParameters{
			AlertText: "Incoming Git request. Open Krypton to continue.",
			Timeout:   timeouts.Sign,
		}
	}

	if r.HostsRequest != nil {
		return RequestParameters{
			AlertText: "Incoming host list request. Open Krypton to continue.",
			Timeout:   timeouts.Sign,
		}
	}

	return RequestParameters{
		AlertText: "Incoming Krypton request. ",
		Timeout:   timeouts.Sign,
	}
}

type Response struct {
	RequestID       string           `json:"request_id"`
	Version         semver.Version   `json:"v"`
	SignResponse    *SignResponse    `json:"sign_response,omitempty"`
	GitSignResponse *GitSignResponse `json:"git_sign_response,omitempty"`
	MeResponse      *MeResponse      `json:"me_response,omitempty"`
	UnpairResponse  *UnpairResponse  `json:"unpair_response,omitempty"`
	AckResponse     *AckResponse     `json:"ack_response,omitempty"`
	HostsResponse   *HostsResponse   `json:"hosts_response,omitempty"`
	SNSEndpointARN  *string          `json:"sns_endpoint_arn,omitempty"`
	TrackingID      *string          `json:"tracking_id,omitempty"`

	ReadTeamResponse      *json.RawMessage `json:"read_team_response,omitempty"`
	TeamOperationResponse *json.RawMessage `json:"team_operation_response,omitempty"`
	LogDecryptionResponse *json.RawMessage `json:"log_decryption_response,omitempty"`
}

type SignRequest struct {
	//	N.B. []byte marshals to base64 encoding in JSON
	Data []byte `json:"data"`
	//	SHA256 hash of SSH wire format
	PublicKeyFingerprint []byte    `json:"public_key_fingerprint"`
	Command              *string   `json:"command,omitempty"`
	HostAuth             *HostAuth `json:"host_auth,omitempty"`
}

type SignResponse struct {
	Signature *[]byte `json:"signature,omitempty"`
	Error     *string `json:"error,omitempty"`
}

type GitSignRequest struct {
	Commit *CommitInfo `json:"commit,omitempty"`
	Tag    *TagInfo    `json:"tag,omitempty"`
	UserId string      `json:"user_id"`
}

type GitSignResponse struct {
	Signature *[]byte `json:"signature,omitempty"`
	Error     *string `json:"error,omitempty"`
}

type HostsRequest struct{}

type UserAndHost struct {
	User string `json:"user"`
	Host string `json:"host"`
}

type HostInfo struct {
	Hosts      []UserAndHost `json:"hosts"`
	PGPUserIDs []string      `json:"pgp_user_ids"`
}
type HostsResponse struct {
	HostInfo *HostInfo `json:"host_info,omitempty"`
	Error    *string   `json:"error,omitempty"`
}

func (gsr GitSignResponse) AsciiArmorSignature(protocolVersion semver.Version) (s string, err error) {
	if gsr.Signature == nil {
		err = fmt.Errorf("no signature")
		return
	}
	output := &bytes.Buffer{}
	headers := KRYPTON_ASCII_ARMOR_HEADERS
	//  FIXME: sunset backwards compatibility
	if protocolVersion.LT(ENCLAVE_VERSION_SUPPORTS_KRYPTON_ASCII_ARMOR_HEADERS) {
		headers = KRYPTONITE_ASCII_ARMOR_HEADERS
	}
	input, err := armor.Encode(output, "PGP SIGNATURE", headers)
	if err != nil {
		return
	}
	_, err = input.Write(*gsr.Signature)
	if err != nil {
		return
	}
	err = input.Close()
	if err != nil {
		return
	}
	s = string(output.Bytes())
	return
}

type CommitInfo struct {
	Tree         string    `json:"tree"`
	Parent       *string   `json:"parent,omitempty"`
	MergeParents *[]string `json:"merge_parents,omitempty"`
	Author       string    `json:"author"`
	Committer    string    `json:"committer"`
	Message      []byte    `json:"message"`
}

type TagInfo struct {
	Object  string `json:"object"`
	Type    string `json:"type"`
	Tag     string `json:"tag"`
	Tagger  string `json:"tagger"`
	Message []byte `json:"message"`
}

type MeRequest struct {
	PGPUserId *string `json:"pgp_user_id,omitempty"`
}

type MeResponse struct {
	Me Profile `json:"me"`
}

func (request Request) HTTPRequest() (httpRequest *http.Request, err error) {
	requestJson, err := json.Marshal(request)
	if err != nil {
		return
	}
	httpRequest, err = http.NewRequest("PUT", "/enclave", bytes.NewReader(requestJson))
	if err != nil {
		return
	}
	return
}

func (request Request) IsNoOp() bool {
	return request.SignRequest == nil && request.MeRequest == nil && request.UnpairRequest == nil
}

type UnpairRequest struct{}

type UnpairResponse struct{}

type AckResponse struct{}

func (r Response) Error() *string {
	if r.GitSignResponse != nil {
		return r.GitSignResponse.Error
	}
	if r.SignResponse != nil {
		return r.SignResponse.Error
	}
	if r.HostsResponse != nil {
		return r.HostsResponse.Error
	}

	return nil
}
